import java.util.Arrays;
import java.util.Scanner;

public class Question2 {
    public static void main(String[] args) {
        System.out.println(minchar("hello",0));

    }
    public static char minchar(String input, int position){
        char min = 'z';
        if(position < input.length()){
            if(input.charAt(position) < min){
                min = input.charAt(position);

            }
            char values = minchar(input, position+1);
            if (values < min) {
                min = values;
            }

        }
        return min;
    }
    }








