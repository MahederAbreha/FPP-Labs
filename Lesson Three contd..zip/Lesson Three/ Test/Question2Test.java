import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class Question2Test {

    @Test
    void minchar() {
        String actual= String.valueOf(Question2.minchar("blue", 0));
        String expected= "b";
        assertEquals(actual, expected);

    }
}