import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class WordCountTest {

    @Test
    public static void main(String[] args) {
        WordCount c1= new WordCount();
        c1.count();
    }
}