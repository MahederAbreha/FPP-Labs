public class Lesson {
    public static void main(String[] args) {
        //String str = "mahi";

    }


//    public static int length(String str) {
//        if (str == null || str.equals("")) {
//            return 0;
//        } else {
//            return 1 + length(str.substring(1));
//            System.out.println(str.charAt(0));
//        }
//
//    }
}
