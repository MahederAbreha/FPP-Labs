import java.util.Scanner;

public class Question1 {
    public static void main(String[] args) {

        Scanner scan= new Scanner(System.in);
        System.out.println("Enter x .");
        double x=  scan.nextDouble();
        System.out.println("Enter n .");

        int n=  scan.nextInt();
        double result = power(x, n);

        System.out.println(result);

    }
    public static double power(double x, int n){

        if(n!=0){
            return (x* power(x, n-1));
        }
        else{
           return 1;
        }

    }
}
